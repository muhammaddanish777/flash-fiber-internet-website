const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');

menuToggle.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
});

mainNav.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    mainNav.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
  });
});

document.getElementById('year').textContent = new Date().getFullYear();

document.querySelectorAll('[data-package]').forEach(link => {
  link.addEventListener('click', () => {
    const select = document.getElementById('packageSelect');
    select.value = link.dataset.package;
  });
});

document.getElementById('bookingForm').addEventListener('submit', event => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.reportValidity()) return;

  const data = new FormData(form);
  const message = [
    'Assalam-o-Alaikum, I want to request a Flash Fiber Internet connection.',
    '',
    `Name: ${data.get('name')}`,
    `Mobile: ${data.get('phone')}`,
    `Area / Address: ${data.get('address')}`,
    `Package: ${data.get('package')}`,
    `Connection type: ${data.get('type')}`,
    `Message: ${data.get('message') || 'None'}`
  ].join('\\n');

  const whatsappNumber = '923020299417'; // Manager: Muhammad Danish
  document.getElementById('formFeedback').textContent =
    'Opening WhatsApp. Please review your details and press Send to submit your request.';
  window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`, '_blank', 'noopener');
});
