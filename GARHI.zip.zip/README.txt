FLASH FIBER INTERNET WEBSITE
============================

Files:
- index.html : website content and sections
- style.css  : responsive design and animations
- script.js  : mobile navigation, package selection, WhatsApp booking form

HOW TO RUN:
1. Extract the ZIP file.
2. Open the folder in VS Code.
3. Double-click index.html, or use the Live Server extension.
4. Test the booking form. It opens WhatsApp with a pre-filled message.

IMPORTANT TO CUSTOMIZE BEFORE PUBLIC LAUNCH:
- Confirm package prices, installation charges and actual available speeds.
- Confirm exact coverage streets/areas in Garhi Hassan Sarki and Thul.
- Confirm business address, support hours and service availability.
- The booking form sends details to the manager's WhatsApp number.
- The speed test button opens Cloudflare's public speed test.
- This is a front-end website. It does not yet include a database, admin login,
  customer portal, bill payment, or automatic complaint tracking.
- Replace or update any business details if they change.

CONTACTS CURRENTLY INCLUDED:
Owners:
Muhammad Salah Buriro - 03073919394
Meer Siraj Khan Sarki - 03003175808
Manager:
Muhammad Danish - 03020299417
Email:
garhifiberinternet@gmail.com
